import React, { useEffect, useState, useRef } from 'react';
import io from 'socket.io-client';
import mermaid from 'mermaid';
import { TransformWrapper, TransformComponent } from 'react-zoom-pan-pinch';
import { 
  Play, Pause, SkipBack, SkipForward, FastForward, 
  Terminal, Move 
} from 'lucide-react';

const socket = io('http://localhost:5000');

// Configuración de Mermaid para modo oscuro
mermaid.initialize({ 
  startOnLoad: false, 
  securityLevel: 'loose', 
  theme: 'base', 
  themeVariables: {
    darkMode: true,
    background: '#171717',
    primaryColor: '#262626',
    lineColor: '#a3a3a3',
    textColor: '#ffffff',
    mainBkg: '#171717',
  }
});

interface HistoryStep {
  node: string;
  console: string;
}

function App() {
  // === ESTADOS ===
  const [history, setHistory] = useState<HistoryStep[]>([]);
  const [viewIndex, setViewIndex] = useState(-1);
  const [isPaused, setIsPaused] = useState(false);
  
  const logsEndRef = useRef<HTMLDivElement>(null);
  const mermaidRef = useRef<HTMLDivElement>(null);

  // === AUTO-SCROLL LOGS ===
  useEffect(() => {
    if (viewIndex === history.length - 1) {
      logsEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [history, viewIndex]);

  // === SOCKETS ===
  useEffect(() => {
    socket.on('ui_update', (data) => {
      setHistory((prev) => {
        const newHistory = [...prev, data];
        setViewIndex((currentIndex) => {
            // Si estamos al final (Live), seguimos al final
            if (currentIndex === prev.length - 1) return newHistory.length - 1;
            return currentIndex;
        });
        return newHistory;
      });
    });

    socket.on('pause_state', (state) => setIsPaused(state));

    return () => {
      socket.off('ui_update');
      socket.off('pause_state');
    };
  }, []);

  // === CONTROLES ===
  const handleTogglePause = () => socket.emit('toggle_pause');
  
  const stepBack = () => {
    if (!isPaused) socket.emit('toggle_pause');
    setViewIndex((prev) => (prev > 0 ? prev - 1 : 0));
  };

  const stepForward = () => {
    setViewIndex((prev) => {
        const next = prev + 1;
        return next >= history.length - 1 ? history.length - 1 : next;
    });
  };

  const goLive = () => setViewIndex(history.length - 1);

  // === DATOS ACTUALES ===
  const currentStep = history[viewIndex] || { node: 'Start', console: '' };
  const activeNode = currentStep.node;
  const visibleLogs = history.slice(0, viewIndex + 1);
  const isInPast = viewIndex < history.length - 1;

  // === RENDER MERMAID ===
  useEffect(() => {
    const renderDiagram = async () => {
      const baseGraph = `---
config:
  theme: neo-dark
  layout: elk
---
flowchart TB
    Start(("Inicio")) --> Init["Inicializar Listas"]
    Init --> Anim@{ label: "Animación" }
    Anim --> Clear["Limpiar Pantalla"]
    Clear --> Metrics["Calcular Métricas"]
    Metrics --> Header["Imprimir Header"]
    Header --> Sort["Ordenar Tareas"]
    Sort --> Filter["Aplicar Filtro"]
    Filter --> RowLoop{"Recorrer Tareas"}
    RowLoop -- Tarea --> CheckStatus{"¿Terminada?"}
    CheckStatus -- Sí --> ColorCyan["Color CYAN"]
    CheckStatus -- No --> CheckDate{"Fecha vs Hoy"}
    CheckDate -- Vencida --> ColorRed["Color ROJO"]
    CheckDate -- Vence Hoy --> ColorYellow["Color AMARILLO"]
    CheckDate -- A Tiempo --> ColorGreen["Color VERDE"]
    ColorCyan --> PrintRow["Imprimir Fila"]
    ColorRed --> PrintRow
    ColorYellow --> PrintRow
    ColorGreen --> PrintRow
    PrintRow --> RowLoop
    RowLoop -- Fin Lista --> Menu["Mostrar Menú"]
    Menu --> Input[/"Input Usuario"/]
    Input -- 1 --> Op1["Nueva Tarea"]
    Op1 --> PrioMenu["Menú Prioridades"]
    PrioMenu --> DateLoop{"Validar Fecha"}
    DateLoop -- Válido --> AddTask["Agregar a tasks"]
    AddTask --> Log1["> Log Session"]
    Log1 --> Clear
    Input -- 2 --> Op2["Modificar Tarea"]
    Op2 --> StateMenu["Menú Estados"]
    StateMenu --> CheckTerm{"¿Nuevo Estado=3?"}
    CheckTerm -- No --> UpdateStat["Actualizar Estado"]
    CheckTerm -- Sí --> AskTime[/"Input Tiempo"/]
    AskTime --> ValidTime{"¿Es Número?"}
    ValidTime -- No --> Cancel["Cancelar"]
    ValidTime -- Sí --> UpdateTime["Update + Tiempo"]
    UpdateStat --> Log2["> Log Session"]
    UpdateTime --> Log2
    Log2 --> Clear
    Cancel --> Clear
    Input -- 3 --> Op3["Borrar Tarea"]
    Op3 --> DelTask["Eliminar"]
    DelTask --> Log3["> Log Session"]
    Log3 --> Clear
    Input -- 4 --> Op4["Cambiar Filtro"]
    Op4 --> Clear
    Input -- 5 --> Op5["Salir"]
    Op5 --> PrintLog["RESUMEN SESIÓN"]
    PrintLog --> End(("Fin"))

    Anim@{ shape: rect}`;

      const highlightStyle = activeNode 
        ? `\nstyle ${activeNode} fill:#ef4444,stroke:#facc15,stroke-width:4px,color:#fff`
        : '';
      
      try {
        if (mermaidRef.current) mermaidRef.current.innerHTML = '';
        const { svg } = await mermaid.render('mermaid-svg-id', baseGraph + highlightStyle);
        if (mermaidRef.current) mermaidRef.current.innerHTML = svg;
      } catch (error) { console.error(error); }
    };
    renderDiagram();
  }, [activeNode]);

  return (
    <div className="flex flex-col h-screen w-screen bg-neutral-950 text-gray-200 overflow-hidden font-sans">
      
      {/* === 1. HEADER === */}
      <header className="h-12 bg-neutral-900 border-b border-neutral-800 flex items-center justify-between px-4 shrink-0 z-20 relative">
        <div className="flex items-center gap-2 text-sm font-semibold text-neutral-400">
          <Move className="w-4 h-4" /> <span>Kanban Flowchart</span>
        </div>
        
        <div className="flex items-center gap-2">
          <button onClick={stepBack} disabled={viewIndex <= 0} className="p-2 hover:bg-neutral-800 rounded text-neutral-400 disabled:opacity-30 transition">
            <SkipBack className="w-5 h-5" />
          </button>

          <button 
            onClick={handleTogglePause}
            className={`p-2 rounded transition ${isPaused ? 'bg-yellow-600 text-white hover:bg-yellow-500' : 'bg-neutral-800 text-green-400 hover:bg-neutral-700'}`}
          >
            {isPaused ? <Play className="w-5 h-5 fill-current" /> : <Pause className="w-5 h-5 fill-current" />}
          </button>

          <button onClick={stepForward} disabled={!isInPast} className="p-2 hover:bg-neutral-800 rounded text-neutral-400 disabled:opacity-30 transition">
            <SkipForward className="w-5 h-5" />
          </button>

          {isInPast && (
            <button onClick={goLive} className="ml-2 p-1.5 px-3 bg-red-600 hover:bg-red-500 text-white text-xs font-bold rounded flex items-center gap-1 transition animate-pulse">
              <FastForward className="w-4 h-4" /> LIVE
            </button>
          )}
        </div>
        
        <div className="text-xs text-neutral-500 w-32 text-right">
            Paso: {viewIndex + 1} / {history.length}
        </div>
      </header>

      {/* === 2. ÁREA PRINCIPAL (SOLO DIAGRAMA) === */}
      <div className="flex-1 flex min-h-0 relative bg-neutral-900 overflow-hidden"> 
          
          <div className="absolute top-4 left-4 z-10 bg-black/60 p-2 rounded backdrop-blur-sm pointer-events-none">
            <p className="text-xs text-neutral-400 font-mono">
                Scroll: Zoom <br/> Arrastrar: Pan
            </p>
          </div>

          <TransformWrapper
              initialScale={1}
              minScale={0.2}
              maxScale={8}
              centerOnInit={true}
              wheel={{ step: 0.1 }}
          >
              <TransformComponent 
                wrapperStyle={{ width: "100%", height: "100%" }}
                contentStyle={{ width: "100%", height: "100%" }}
              >
                  <div 
                      ref={mermaidRef} 
                      className="w-full h-full flex items-center justify-center"
                      style={{ minWidth: '100vw', minHeight: '100vh' }} 
                  />
              </TransformComponent>
          </TransformWrapper>
      </div>

      {/* === 3. TERMINAL INFERIOR === */}
      <div className="h-48 border-t border-neutral-800 bg-black flex flex-col shrink-0 z-20 relative">
        <div className="h-7 bg-neutral-900 border-b border-neutral-800 flex items-center px-3 gap-2">
            <Terminal className="w-3.5 h-3.5 text-neutral-400" />
            <span className="text-xs font-mono text-neutral-400">Terminal Output</span>
        </div>
        
        <div className="flex-1 overflow-y-auto p-2 font-mono text-sm space-y-1">
            {visibleLogs.map((item, index) => (
                <div key={index} className={`flex ${index === viewIndex ? 'bg-neutral-900 text-white' : 'text-neutral-500'}`}>
                    <span className="select-none w-8 text-neutral-700 text-right mr-3 border-r border-neutral-800 pr-2">{index + 1}</span>
                    <span className={index === viewIndex ? 'text-green-400 font-bold' : ''}>
                        {index === viewIndex && '> '} {item.console}
                    </span>
                </div>
            ))}
            <div ref={logsEndRef} />
        </div>
      </div>

    </div>
  );
}

export default App;