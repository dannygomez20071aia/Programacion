import os
import time
import linecache
from datetime import datetime
import requests 

# ==============================================================================
#   COMUNICACIÓN CON FRONTEND (MODO ESPEJO)
# ==============================================================================
def notificar_frontend(nodo_diagrama, texto_consola="", rango_lineas=None):
    url_update = "http://localhost:5000/update"
    url_status = "http://localhost:5000/status"
    
    # === AQUI ESTA LA MAGIA ===
    # Leemos el archivo "original_code.py" en lugar de este script
    source_code = ""
    if rango_lineas:
        start, end = rango_lineas
        # Leemos del archivo LIMPIO
        lines = [linecache.getline('original_code.py', i) for i in range(start, end + 1)]
        source_code = "".join(lines)

    try:
        data = { "node": nodo_diagrama, "console": texto_consola, "sourceCode": source_code }
        requests.post(url_update, json=data, timeout=0.1)
    except:
        pass 
    
    time.sleep(1.5) 
    
    # Lógica de Pausa
    while True:
        try:
            resp = requests.get(url_status, timeout=0.2)
            if resp.json().get("paused") is True:
                time.sleep(1)
            else:
                break
        except:
            break

# ==============================================================================
#   INICIO Y CONFIGURACIÓN
# ==============================================================================
# Mapeado a original_code.py: Imports y definición de listas
notificar_frontend("Start", "Iniciando programa...", (1, 15))

tasks = [] 
session_log = [] 
ultimo_id = 0 
mensaje_sistema = "Sistema listo. Se registrarán tus cambios al salir."
ancho = 80 
filtro_actual = None 

# Mapeado a original_code.py: Variables iniciales
notificar_frontend("Init", "Inicializando listas: tasks y session_log", (9, 15))

ref_estados = {1: "PENDIENTE", 2: "EN PROCESO", 3: "TERMINADO"}
ref_prioridades = {1: "BAJA", 2: "MEDIA", 3: "ALTA"}
RESET = "\033[0m"
RED = "\033[91m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
WHITE = "\033[97m"
MAGENTA = "\033[95m" 

# ==============================================================================
#   ANIMACIÓN
# ==============================================================================
# Mapeado a original_code.py: Bloque de animación (Lines 29-51 aprox)
notificar_frontend("Anim", "Ejecutando Animación 'Ola de Colores'", (29, 51))

os.system("cls" if os.name == "nt" else "clear")
texto = "Bienvenido a Kanbancito CLI"
longitud = len(texto)

for _ in range(3):
    for i in range(longitud + 5):
        resultado = ""
        for indice, char in enumerate(texto):
            if indice == i: resultado += f"{WHITE}{char}"
            elif indice == i - 1: resultado += f"{CYAN}{char}"
            else: resultado += f"{GREEN}{char}"
        print(f"\r{resultado}{RESET}", end='', flush=True)
        time.sleep(0.04)

print(f"\r{GREEN}{texto}{RESET}") 
print()

# ==============================================================================
#   BUCLE PRINCIPAL
# ==============================================================================
while True:
    # Mapeado a original_code.py: Inicio del While y limpieza (57-63)
    notificar_frontend("Clear", "Limpiando pantalla...", (57, 63))
    
    os.system("cls" if os.name == "nt" else "clear")
    try: ancho = os.get_terminal_size().columns
    except: ancho = 80

    # --------------------------------------------------------------------------
    #   MÉTRICAS
    # --------------------------------------------------------------------------
    # Mapeado a original_code.py: Cálculo de métricas (68-78)
    notificar_frontend("Metrics", "Calculando métricas (Donny)...", (68, 78))    
     
    total_tareas = len(tasks)
    total_done = 0
    tiempo_total = 0
    for _t in tasks:
        if _t[2] == 3: total_done += 1
        tiempo_total += _t[5]
    porcentaje = 0.0
    if total_tareas > 0: porcentaje = (total_done / total_tareas) * 100

    # --------------------------------------------------------------------------
    #   HEADER
    # --------------------------------------------------------------------------
    # Mapeado a original_code.py: Print header (83-89)
    notificar_frontend("Header", f"Imprimiendo estadísticas: {int(porcentaje)}%", (83, 89))
    
    print("=" * ancho)
    ahora = datetime.now()
    fecha_hoy_str = ahora.strftime("%Y-%m-%d")
    stats_str = f"Tareas: {total_tareas} | Done: {total_done} ({porcentaje:.1f}%) | T.Inv: {tiempo_total}m"
    padding = (ancho - len(stats_str)) // 2
    print(" " * padding + stats_str)
    print("=" * ancho)

    # --------------------------------------------------------------------------
    #   ORDENAMIENTO
    # --------------------------------------------------------------------------
    # Mapeado a original_code.py: Bubble Sort (94-102)
    notificar_frontend("Sort", "Ordenando: Prioridad > ID", (94, 102))
    
    print(f"{'ID':<4} | {'ESTADO':<11} | {'PRIO':<8} | {'FECHA LIMITE':<12} | {'AVISO / TAREA'}")
    print("=" * ancho)

    lista_ordenada = tasks[:]
    n = len(lista_ordenada)
    for i in range(n):
        for j in range(n - i - 1):
            a = lista_ordenada[j]
            b = lista_ordenada[j + 1]
            if a[3] < b[3] or (a[3] == b[3] and a[0] > b[0]): 
                lista_ordenada[j], lista_ordenada[j + 1] = b, a

    # --------------------------------------------------------------------------
    #   FILTRO
    # --------------------------------------------------------------------------
    # Mapeado a original_code.py: Filtro (105-110)
    notificar_frontend("Filter", f"Filtro activo: {filtro_actual if filtro_actual else 'Ninguno'}", (105, 110))
    
    if filtro_actual is not None:
        lista_a_mostrar = [t for t in lista_ordenada if t[3] == filtro_actual]
        aviso_filtro = f"[FILTRO ACTIVO: {ref_prioridades.get(filtro_actual)}]"
    else:
        lista_a_mostrar = lista_ordenada
        aviso_filtro = ""

    # --------------------------------------------------------------------------
    #   RENDER LOOP
    # --------------------------------------------------------------------------
    # Mapeado a original_code.py: Inicio del for (113)
    notificar_frontend("RowLoop", f"Iterando {len(lista_a_mostrar)} tareas...", (113, 114))
    
    for _t in lista_a_mostrar:
        time.sleep(0.05) 
        t_id, t_nombre, t_est, t_prio, t_fecha_str, t_tiempo = _t
        nombre_est = ref_estados.get(t_est, "???")
        nombre_prio = ref_prioridades.get(t_prio, "???")
        color_fila = RESET
        aviso_jandry = ""
        
        # Mapeado a original_code.py: Check Status (121-122)
        notificar_frontend("CheckStatus", f"ID {t_id}: Verificando estado...", (121, 122))
        
        try:
            fecha_tarea = datetime.strptime(t_fecha_str, "%Y-%m-%d")
            
            if t_est != 3:
                # Mapeado a original_code.py: Check Date (123-124)
                notificar_frontend("CheckDate", f"ID {t_id}: Comparando fecha vs Hoy", (123, 124))
                
                if fecha_tarea.date() < ahora.date():
                    notificar_frontend("ColorRed", "Vencida -> ROJO", (124, 126))
                    color_fila = RED
                    aviso_jandry = f"{RED}[YA VENCIÓ X]{RESET} "
                elif fecha_tarea.date() == ahora.date():
                    notificar_frontend("ColorYellow", "Vence hoy -> AMARILLO", (127, 129))
                    color_fila = YELLOW
                    aviso_jandry = f"{YELLOW}[VENCE HOY !]{RESET} "
                else:
                    notificar_frontend("ColorGreen", "A tiempo -> VERDE", (130, 131))
                    color_fila = GREEN
            else:
                notificar_frontend("ColorCyan", "Tarea terminada -> CYAN", (132, 133))
                color_fila = CYAN 

        except ValueError:
            aviso_jandry = "[Error Fecha] "

        # Mapeado a original_code.py: Print Fila (136-141)
        notificar_frontend("PrintRow", f"Imprimiendo ID {t_id}", (136, 141))
        
        fmt_id = f"{t_id:<4}"
        fmt_est = f"{color_fila}{nombre_est:<11}{RESET}"
        fmt_prio = f"{nombre_prio:<8}"
        fmt_fecha = f"{t_fecha_str:<12}"
        print(f"{fmt_id} | {fmt_est} | {fmt_prio} | {fmt_fecha} | {aviso_jandry}{t_nombre}")

    if len(tasks) == 0:
        print(f"\n{'[ La lista está vacía ]':^{ancho}}\n")

    # --------------------------------------------------------------------------
    #   MENÚ
    # --------------------------------------------------------------------------
    # Mapeado a original_code.py: Menú principal (146-155)
    notificar_frontend("Menu", "Mostrando opciones principales", (146, 155))
    
    print("-" * ancho)
    if aviso_filtro: print(aviso_filtro)
    print(" [1] Nueva Tarea   [2] Modificar   [3] Borrar   [4] Filtrar   [5] Salir")
    print("-" * ancho)

    if mensaje_sistema:
        print(f" >> SISTEMA: {mensaje_sistema}")
        mensaje_sistema = ""
        print("-" * ancho)
    
    notificar_frontend("Input", "Esperando input de usuario...", (157, 157))
    opcion = input(" Acción > ")

    # ==========================================================================
    #   OPCIÓN 1
    # ==========================================================================
    if opcion == "1":
        # Mapeado a original_code.py: Opción 1 Inicio (162-164)
        notificar_frontend("Op1", "Seleccionada Opción 1", (162, 164))
        print("\n [NUEVA TAREA]")
        in_nombre = input(" Nombre: ")

        if in_nombre:
            # Mapeado a original_code.py: Menú Prio (167-175)
            notificar_frontend("PrioMenu", "Menú Prioridades (Danny)", (167, 175))
            print("=================="); print("====PRIORIDADES==="); print("==================")
            print("== 1. BAJA =="); print("== 2. MEDIA =="); print("== 3. ALTA ==")
            print("-------------------------------------------")
            
            prio_input = input("Elige el item > ")
            prio_final = 1
            if prio_input in ["1", "2", "3"]: prio_final = int(prio_input)
            else: print(" Entrada inválida. Se asigna BAJA.")

            fecha_final = ""
            print(f" Fecha Límite (Ej: {fecha_hoy_str})")
            
            # Mapeado a original_code.py: Date Loop (186-196)
            notificar_frontend("DateLoop", "Validando fecha (Jandry)", (186, 196))
            while True:
                entrada_f = input(" > ").strip()
                if entrada_f == "":
                    fecha_final = fecha_hoy_str
                    break
                try:
                    datetime.strptime(entrada_f, "%Y-%m-%d")
                    fecha_final = entrada_f
                    break 
                except ValueError: print(f"{RED} Error: Formato incorrecto.{RESET}")

            ultimo_id += 1
            # Mapeado a original_code.py: Append Task (198)
            notificar_frontend("AddTask", f"Agregando ID {ultimo_id} a tasks", (198, 198))
            tasks.append([ultimo_id, in_nombre, 1, prio_final, fecha_final, 0])
            
            # Mapeado a original_code.py: Log Append (201)
            notificar_frontend("Log1", "Registrando creación", (201, 201))
            session_log.append(f"{GREEN}[CREADA]{RESET} ID {ultimo_id}: {in_nombre}")
            mensaje_sistema = f"Tarea ID {ultimo_id} agregada."
        else:
            mensaje_sistema = "Error: Nombre vacío."

    # ==========================================================================
    #   OPCIÓN 2
    # ==========================================================================
    elif opcion == "2":
        # Mapeado a original_code.py: Opción 2 inicio (207)
        notificar_frontend("Op2", "Seleccionada Opción 2", (207, 207))
        in_id = input(" ID a modificar: ")
        
        tarea = None
        for _t in tasks:
            if str(_t[0]) == in_id:
                tarea = _t
                break

        if not tarea:
            notificar_frontend("Cancel", "ID no encontrado", (215, 215))
            mensaje_sistema = "Error: ID no existe."
        else:
            print(f" Editando: {tarea[1]}")
            # Mapeado a original_code.py: Menu Estados (219-227)
            notificar_frontend("StateMenu", "Menú Estados (Danny)", (219, 227))
            
            print("==================="); print("===== ESTADOS ====="); print("===================")
            print("== 1. PENDIENTE =="); print("== 2. EN PROCESO =="); print("== 3. TERMINADO ==")
            print("-------------------------------------------")
            
            estado_input = input("Elige el item > ")
            es_valido = False
            if not estado_input.isdigit(): mensaje_sistema = " Error: solo se permiten números del 1 al 3"
            else:
                nuevo_estado = int(estado_input)
                if nuevo_estado < 1 or nuevo_estado > 3: mensaje_sistema = " Revisa y vuelve a elegir el item"
                else: es_valido = True

            if es_valido:
                tiempo_a_sumar = 0
                error_donny = False
                
                # Mapeado a original_code.py: CheckTerm logic (241-242)
                notificar_frontend("CheckTerm", f"¿Nuevo estado es 3? ({nuevo_estado==3})", (241, 242))
                
                if nuevo_estado == 3:
                    # Mapeado a original_code.py: Input Tiempo (243)
                    notificar_frontend("AskTime", "Pidiendo tiempo invertido (Donny)", (243, 243))
                    tiempo_str = input(" Minutos invertidos: ")
                    
                    # Mapeado a original_code.py: Valid Time (244-245)
                    notificar_frontend("ValidTime", "¿Es número válido?", (244, 245))
                    if not tiempo_str.isdigit():
                        notificar_frontend("Cancel", "Error: No es número", (245, 245))
                        mensaje_sistema = "Error: Solo números enteros."
                        error_donny = True 
                    else:
                        tiempo_a_sumar = int(tiempo_str)
                
                if not error_donny:
                    est_antiguo = ref_estados.get(tarea[2])
                    tarea[2] = nuevo_estado
                    cambio_log = f"{YELLOW}[MODIFICADA]{RESET} ID {tarea[0]}: {est_antiguo} -> {ref_estados.get(nuevo_estado)}"
                    
                    if tiempo_a_sumar > 0:
                        # Mapeado a original_code.py: Sumar tiempo (255)
                        notificar_frontend("UpdateTime", "Actualizando Estado + Tiempo", (255, 255))
                        tarea[5] += tiempo_a_sumar
                        cambio_log += f" (+{tiempo_a_sumar} min)"
                    else:
                        notificar_frontend("UpdateStat", "Actualizando solo Estado", (252, 252))
                    
                    # Mapeado a original_code.py: Log Mod (258)
                    notificar_frontend("Log2", "Guardando en log", (258, 258))
                    session_log.append(cambio_log)
                    mensaje_sistema = "Tarea actualizada correctamente."

    # ==========================================================================
    #   OPCIÓN 3
    # ==========================================================================
    elif opcion == "3":
        # Mapeado a original_code.py: Opción 3 (264)
        notificar_frontend("Op3", "Seleccionada Opción 3", (264, 264))
        in_id = input("ID a borrar: ")
        idx = -1
        for i, _t in enumerate(tasks):
            if str(_t[0]) == in_id:
                idx = i; break
        if idx != -1:
            # Mapeado a original_code.py: Delete (270)
            notificar_frontend("DelTask", f"Eliminando ID {in_id}", (270, 270))
            borrada = tasks.pop(idx)
            
            # Mapeado a original_code.py: Log Del (272)
            notificar_frontend("Log3", "Registrando eliminación", (272, 272))
            session_log.append(f"{RED}[ELIMINADA]{RESET} ID {borrada[0]}: {borrada[1]}")
            mensaje_sistema = f"Tarea '{borrada[1]}' eliminada."
        else:
            mensaje_sistema = "ID no encontrado."

    # ==========================================================================
    #   OPCIÓN 4
    # ==========================================================================
    elif opcion == "4":
        # Mapeado a original_code.py: Filter menu (278-281)
        notificar_frontend("Op4", "Cambiando Filtro", (278, 281))
        print("\n [FILTROS]")
        print(" 1. Ver Todas | 2. Alta | 3. Media | 4. Baja")
        sub = input(" > ")
        if sub == "1": filtro_actual = None
        elif sub == "2": filtro_actual = 3
        elif sub == "3": filtro_actual = 2
        elif sub == "4": filtro_actual = 1

    # ==========================================================================
    #   OPCIÓN 5
    # ==========================================================================
    elif opcion == "5":
        # Mapeado a original_code.py: Exit (286-297)
        notificar_frontend("Op5", "Saliendo...", (286, 297))
        notificar_frontend("PrintLog", "Imprimiendo resumen de sesión")
        
        print("\n" + "="*30)
        print(f" {MAGENTA}RESUMEN DE SESIÓN{RESET}")
        print("="*30)
        if len(session_log) == 0: print(" No realizaste cambios en esta sesión.")
        else:
            for accion in session_log: print(" * " + accion)
        print("="*30)
        print("Cerrando Kanbancito... ¡Buen trabajo!")
        notificar_frontend("End", "Fin del Programa")
        break
    else:
        mensaje_sistema = "Opción inválida."