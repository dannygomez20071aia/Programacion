# server.py
from flask import Flask, request, jsonify
from flask_socketio import SocketIO, emit
from flask_cors import CORS

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*")

# === VARIABLE GLOBAL DE ESTADO ===
IS_PAUSED = False

@app.route('/')
def index():
    return "Servidor Puente Activo"

# 1. Endpoint para que React envíe datos (UI Update)
@app.route('/update', methods=['POST'])
def update_ui():
    data = request.json
    # print(f"Recibido: {data}") # Comentado para no saturar consola
    socketio.emit('ui_update', data)
    return "OK", 200

# 2. Endpoint para que el script de Python PREGUNTE si debe detenerse
@app.route('/status', methods=['GET'])
def check_status():
    return jsonify({"paused": IS_PAUSED}), 200

# 3. Socket: React nos pide cambiar el estado (Pausar/Reanudar)
@socketio.on('toggle_pause')
def handle_toggle_pause():
    global IS_PAUSED
    IS_PAUSED = not IS_PAUSED
    print(f"Estado de pausa cambiado a: {IS_PAUSED}")
    # Avisamos a TODOS los clientes (React) el nuevo estado
    emit('pause_state', IS_PAUSED, broadcast=True)

# 4. Socket: Cuando React se conecta, le decimos cómo está el semáforo
@socketio.on('connect')
def handle_connect():
    emit('pause_state', IS_PAUSED)

if __name__ == '__main__':
    socketio.run(app, port=5000, debug=True)